//
//  HGHeadSwitchView.h
//  HGHeadSwitchView
//
//  Created by xmf on 2017/3/20.
//  Copyright © 2017年 xmf. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol HGHeadSwitchViewDelegate <NSObject>

//单元格点击
- (void)hg_headSwitchViewDidClick:(NSInteger)index;

@end

@interface HGHeadSwitchView : UIView

//初始化
- (id)initWithFrame:(CGRect)frame Title:(NSArray *)titles Color:(NSArray*)colors;

@property (nonatomic,assign)id<HGHeadSwitchViewDelegate>delegate;
@property (nonatomic,strong)NSArray *items; //标题
@property (nonatomic,strong)NSArray *colors; //单元格背景颜色
@property (nonatomic,assign)CGFloat itemH; 
@property (nonatomic,assign)CGFloat itemW;
@property (nonatomic,assign)NSInteger buttonTag; 
@end
