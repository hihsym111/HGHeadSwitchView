//
//  HGHeadSwitchView.m
//  HGHeadSwitchView
//
//  Created by xmf on 2017/3/20.
//  Copyright © 2017年 xmf. All rights reserved.
//

#import "HGHeadSwitchView.h"

#define kTopLineH 2 //顶部短横线高度
#define kAnimationDuration 0.15 //单元格动画时间
@implementation HGHeadSwitchView

- (id)initWithFrame:(CGRect)frame Title:(NSArray *)titles Color:(NSArray *)colors{
    self = [super initWithFrame:frame];
    if (self) {
        _itemW = self.frame.size.width/titles.count;
        _itemH = self.frame.size.height;
        [self initHeadView:titles Color:colors];
        _items = titles;
    }
    return self;
}

- (void)initHeadView: (NSArray *)array Color:(NSArray *)colors{
    
    for (int i=0; i<array.count; i++) {
        UIButton * btn = [UIButton buttonWithType:UIButtonTypeCustom];
        btn.frame = CGRectMake(_itemW*i, 0, _itemW, _itemH);
        [btn setTitle:array[i] forState:0];
        [btn setTitleColor:[UIColor blackColor] forState:0];
        btn.tag = 100+i;
        [btn addTarget:self action:@selector(click:) forControlEvents:UIControlEventTouchUpInside];
        [self addSubview:btn];
        
        UIView * view = [UIView new];
        view.frame = CGRectMake(_itemW*i, -_itemH+kTopLineH, _itemW, _itemH);
        view.backgroundColor = colors[i];
        view.tag = 1000+i;
        [self insertSubview:view belowSubview:btn];
        //默认选择第一个
        if (i==0) {
            [btn setTitleColor:[UIColor whiteColor] forState:0];
            view.frame = CGRectMake(_itemW*i, 0, _itemW, _itemH);
        }
    }
}

//点击改变单元格状态
- (void)click: (UIButton *)sender{

    for (int i=0; i<_items.count; i++) {
        UIView *view = [self viewWithTag:i+1000];
        UIButton *btn = [self viewWithTag:i+100];
        //点击当前按钮变化
        if (i==sender.tag-100 ) {
            [btn setTitleColor:[UIColor whiteColor] forState:0];
            [UIView animateWithDuration:kAnimationDuration animations:^{
                view.frame = CGRectMake(_itemW*i, 0, _itemW, _itemH);
            }];
        //其他按钮变化
        }else{
            [btn setTitleColor:[UIColor blackColor] forState:0];
            [UIView animateWithDuration:kAnimationDuration animations:^{
                view.frame = CGRectMake(_itemW*i, -_itemH+kTopLineH, _itemW, _itemH);
            }];
        }
    }
    if (_delegate && [_delegate respondsToSelector:@selector(hg_headSwitchViewDidClick:)]) {
        [_delegate hg_headSwitchViewDidClick:sender.tag-100];
    }
}

//滑动列表改变单元格状态
- (void)setButtonTag:(NSInteger)buttonTag{
    for (int i=0; i<_items.count; i++) {
        UIView *view = [self viewWithTag:i+1000];
        UIButton *btn = [self viewWithTag:i+100];

        if (i==buttonTag ) {
            [btn setTitleColor:[UIColor whiteColor] forState:0];
            [UIView animateWithDuration:kAnimationDuration animations:^{
                view.frame = CGRectMake(_itemW*i, 0, _itemW, _itemH);
            }];
        }else{
            [btn setTitleColor:[UIColor blackColor] forState:0];
            [UIView animateWithDuration:kAnimationDuration animations:^{
                view.frame = CGRectMake(_itemW*i, -_itemH+kTopLineH, _itemW, _itemH);
            }];
        }
    }

}

@end
