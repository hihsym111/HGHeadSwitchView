//
//  ViewController.m
//  HGHeadSwitchView
//
//  Created by xmf on 2017/3/20.
//  Copyright © 2017年 hg. All rights reserved.
//

#import "ViewController.h"
#import "HGHeadSwitchView.h"

@interface ViewController ()<UITableViewDelegate,UITableViewDataSource,UIScrollViewDelegate,HGHeadSwitchViewDelegate>
{
    HGHeadSwitchView *headview;
    UITableView *tableview;
    NSArray *itemArray;
}

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    itemArray = @[@"交通",@"政务",@"医疗",@"车主",@"综合",@"其他"];
    NSArray *colors = @[[UIColor redColor],[UIColor yellowColor],[UIColor blueColor],[UIColor greenColor],[UIColor orangeColor],[UIColor purpleColor]];
    
    tableview = [[UITableView alloc]initWithFrame:CGRectMake(0, 50, self.view.frame.size.width, self.view.frame.size.height-50) style:UITableViewStyleGrouped];
    tableview.delegate = self;
    tableview.dataSource = self;
    [self.view addSubview:tableview];
    [tableview registerClass:[UITableViewCell class] forCellReuseIdentifier:@"cell"];
    
    headview = [[HGHeadSwitchView alloc]initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, 50) Title:itemArray Color:colors] ;
    headview.delegate = self;
    [self.view addSubview:headview];

}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return itemArray.count;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return 25;
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section{
    return [NSString stringWithFormat:@"%li",section];
}
- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    return 0.001;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    UITableViewCell *cell = [tableview dequeueReusableCellWithIdentifier:@"cell"];
    if (cell==nil) {
        cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"cell"];
    }
    cell.textLabel.text = [NSString stringWithFormat:@"%li",indexPath.row+indexPath.section*10];
    return cell;
}
-(void)scrollViewDidScroll:(UIScrollView *)scrollView{
 
    NSIndexPath*path =  [tableview indexPathForRowAtPoint:CGPointMake(scrollView.contentOffset.x, scrollView.contentOffset.y)];
    headview.buttonTag = path.section;
    
}
- (void)hg_headSwitchViewDidClick:(NSInteger)index{
    [tableview scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:1 inSection:index]  atScrollPosition:UITableViewScrollPositionTop animated:NO];

}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
